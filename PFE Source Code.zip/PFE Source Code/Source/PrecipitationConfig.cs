using System.Collections.Generic;
using UnityEngine;

namespace PlanetFallEffects
{
    public enum PrecipType
    {
        Snow,
        Rain
    }

    public class PrecipitationConfig
    {
        public string body;
        public PrecipType type = PrecipType.Snow;

        public List<string> biomes;
        private HashSet<string> _biomeKeys;

        public float maxAltitude = 6000f;
        public float fadeFraction = 0.25f;
        public float maxSurfaceSpeed = 250f;

        public float fallSpeed;
        public float windSpeed;
        public float velocityJitter;
        public float flutter;

        public float sizeMin;
        public float sizeMax;
        public Color color = Color.white;
        public string texture = string.Empty;
        public float streakScale;

        public float areaRadius = 45f;
        public float spawnHeight = 25f;
        public float killDepth = 35f;

        public float emissionRate;

        public float Lifetime
        {
            get { return (spawnHeight + killDepth) / Mathf.Max(0.1f, fallSpeed); }
        }

        public int MaxParticles
        {
            get { return Mathf.CeilToInt(emissionRate * Lifetime * 1.3f) + 64; }
        }


        public bool IsBiomeRestricted
        {
            get { return _biomeKeys != null && _biomeKeys.Count > 0; }
        }

        public bool MatchesBiome(string biomeName)
        {
            if (_biomeKeys == null || _biomeKeys.Count == 0) return true;
            return _biomeKeys.Contains(NormalizeBiome(biomeName));
        }

        private static string NormalizeBiome(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return s.Trim().ToLowerInvariant()
                    .Replace("_", string.Empty)
                    .Replace("-", string.Empty)
                    .Replace(" ", string.Empty);
        }

        private static void CollectBiomeTokens(ConfigNode node, string key, List<string> into)
        {
            string[] values = node.GetValues(key);
            if (values == null) return;
            for (int i = 0; i < values.Length; i++)
            {
                if (string.IsNullOrEmpty(values[i])) continue;
                string[] parts = values[i].Split(',');
                for (int j = 0; j < parts.Length; j++)
                {
                    string token = parts[j].Trim();
                    if (token.Length > 0) into.Add(token);
                }
            }
        }

        public static PrecipitationConfig Load(ConfigNode node)
        {
            PrecipitationConfig c = new PrecipitationConfig();

            if (!node.TryGetValue("body", ref c.body) || string.IsNullOrEmpty(c.body))
            {
                Debug.LogWarning("[PlanetFallEffects] PFE_PRECIPITATION node missing 'body', skipping.");
                return null;
            }

            node.TryGetEnum("type", ref c.type, PrecipType.Snow);

            if (c.type == PrecipType.Snow)
            {
                c.fallSpeed = 1.0f;
                c.windSpeed = 1.5f;
                c.velocityJitter = 0.25f;
                c.flutter = 0.7f;
                c.sizeMin = 0.03f;
                c.sizeMax = 0.09f;
                c.emissionRate = 350f;
                c.streakScale = 0f;
                c.color = new Color(1f, 1f, 1f, 0.9f);
            }
            else
            {
                c.fallSpeed = 14f;
                c.windSpeed = 2.5f;
                c.velocityJitter = 0.4f;
                c.flutter = 0f;
                c.sizeMin = 0.012f;
                c.sizeMax = 0.02f;
                c.emissionRate = 900f;
                c.streakScale = 0.06f;
                c.color = new Color(0.75f, 0.85f, 1f, 0.45f);
            }

            node.TryGetValue("maxAltitude", ref c.maxAltitude);
            node.TryGetValue("fadeFraction", ref c.fadeFraction);
            node.TryGetValue("maxSurfaceSpeed", ref c.maxSurfaceSpeed);
            node.TryGetValue("fallSpeed", ref c.fallSpeed);
            node.TryGetValue("windSpeed", ref c.windSpeed);
            node.TryGetValue("velocityJitter", ref c.velocityJitter);
            node.TryGetValue("flutter", ref c.flutter);
            node.TryGetValue("sizeMin", ref c.sizeMin);
            node.TryGetValue("sizeMax", ref c.sizeMax);
            node.TryGetValue("color", ref c.color);
            node.TryGetValue("texture", ref c.texture);
            node.TryGetValue("streakScale", ref c.streakScale);
            node.TryGetValue("areaRadius", ref c.areaRadius);
            node.TryGetValue("spawnHeight", ref c.spawnHeight);
            node.TryGetValue("killDepth", ref c.killDepth);
            node.TryGetValue("emissionRate", ref c.emissionRate);

            List<string> biomeList = new List<string>();
            CollectBiomeTokens(node, "biomes", biomeList);
            CollectBiomeTokens(node, "biome", biomeList);
            if (biomeList.Count > 0)
            {
                c.biomes = biomeList;
                c._biomeKeys = new HashSet<string>();
                for (int i = 0; i < biomeList.Count; i++)
                {
                    c._biomeKeys.Add(NormalizeBiome(biomeList[i]));
                }
            }

            c.fadeFraction = Mathf.Clamp(c.fadeFraction, 0.01f, 0.9f);
            return c;
        }
    }
}
