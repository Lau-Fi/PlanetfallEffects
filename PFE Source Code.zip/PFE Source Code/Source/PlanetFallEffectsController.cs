using System.Collections.Generic;
using UnityEngine;

namespace PlanetFallEffects
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class PlanetFallEffectsController : MonoBehaviour
    {
        private const string LogTag = "[PlanetFallEffects]";
        private const int MaxEmitPerFrame = 256;

        private const float BiomeRefreshInterval = 0.25f;

        private static List<PrecipitationConfig> s_configs;

        private PrecipitationConfig _active;
        private GameObject _rig;
        private ParticleSystem _ps;
        private ParticleSystemRenderer _renderer;
        private Material _material;
        private Texture2D _proceduralDot;
        private ParticleSystem.EmitParams _emit;

        private float _emitCarry;
        private bool _needsPrewarm;
        private Vector3 _windAzimuthSeed;

        private string _cachedBiome = string.Empty;
        private float _biomeCacheTime = -1f;


        private void Start()
        {
            LoadConfigsOnce();
            if (s_configs.Count == 0)
            {
                enabled = false;
                return;
            }

            BuildRig();
            _windAzimuthSeed = Random.onUnitSphere;
            GameEvents.onVesselChange.Add(OnVesselChange);
        }

        private void OnDestroy()
        {
            GameEvents.onVesselChange.Remove(OnVesselChange);
            if (_ps != null) FloatingOrigin.UnregisterParticleSystem(_ps);
            if (_rig != null) Destroy(_rig);
            if (_material != null) Destroy(_material);
            if (_proceduralDot != null) Destroy(_proceduralDot);
        }

        private void OnVesselChange(Vessel v)
        {
            _biomeCacheTime = -1f;
            SetActiveConfig(null);
        }

        private static void LoadConfigsOnce()
        {
            if (s_configs != null) return;
            s_configs = new List<PrecipitationConfig>();

            ConfigNode[] nodes = GameDatabase.Instance.GetConfigNodes("PFE_PRECIPITATION");
            for (int i = 0; i < nodes.Length; i++)
            {
                PrecipitationConfig cfg = PrecipitationConfig.Load(nodes[i]);
                if (cfg != null)
                {
                    s_configs.Add(cfg);
                    string region = cfg.IsBiomeRestricted
                        ? "biomes: " + string.Join(", ", cfg.biomes)
                        : "whole body";
                    Debug.Log(LogTag + " Loaded " + cfg.type + " for body '" + cfg.body + "' (" + region + ").");
                }
            }
            Debug.Log(LogTag + " " + s_configs.Count + " precipitation definition(s) loaded.");
        }


        private void BuildRig()
        {
            _rig = new GameObject("PlanetFallEffects.Rig");
            _rig.layer = 0;

            _ps = _rig.AddComponent<ParticleSystem>();
            _renderer = _rig.GetComponent<ParticleSystemRenderer>();

            ParticleSystem.MainModule main = _ps.main;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.playOnAwake = false;
            main.startSpeed = 0f;
            main.maxParticles = 4096;
            main.loop = true;

            ParticleSystem.EmissionModule emission = _ps.emission;
            emission.enabled = false;

            ParticleSystem.ShapeModule shape = _ps.shape;
            shape.enabled = false;

            Shader shader = Shader.Find("Legacy Shaders/Particles/Alpha Blended");
            if (shader == null) shader = Shader.Find("Particles/Alpha Blended");
            if (shader == null)
            {
                Debug.LogError(LogTag + " No alpha-blended particle shader found; disabling.");
                enabled = false;
                return;
            }
            _material = new Material(shader);
            _renderer.material = _material;
            _renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            _renderer.receiveShadows = false;

            _emit = new ParticleSystem.EmitParams();

            FloatingOrigin.RegisterParticleSystem(_ps);

            _ps.Play();
        }

        private Texture2D GetProceduralDot()
        {
            if (_proceduralDot != null) return _proceduralDot;

            const int size = 64;
            _proceduralDot = new Texture2D(size, size, TextureFormat.ARGB32, false);
            float half = (size - 1) * 0.5f;
            Color32[] px = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float d = Mathf.Sqrt((x - half) * (x - half) + (y - half) * (y - half)) / half;
                    float a = Mathf.Clamp01(1f - d);
                    a = a * a * (3f - 2f * a);
                    px[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }
            _proceduralDot.SetPixels32(px);
            _proceduralDot.Apply(false, true);
            return _proceduralDot;
        }


        private PrecipitationConfig SelectConfig(Vessel vessel)
        {
            string bodyName = vessel.mainBody.bodyName;

            bool hasAnyForBody = false;
            bool needsBiome = false;
            for (int i = 0; i < s_configs.Count; i++)
            {
                PrecipitationConfig c = s_configs[i];
                if (c.body != bodyName) continue;
                hasAnyForBody = true;
                if (c.IsBiomeRestricted) needsBiome = true;
            }
            if (!hasAnyForBody) return null;

            string biome = needsBiome ? GetCachedBiome(vessel) : null;

            PrecipitationConfig wholeBody = null;
            for (int i = 0; i < s_configs.Count; i++)
            {
                PrecipitationConfig c = s_configs[i];
                if (c.body != bodyName) continue;

                if (c.IsBiomeRestricted)
                {
                    if (biome != null && c.MatchesBiome(biome)) return c;
                }
                else if (wholeBody == null)
                {
                    wholeBody = c;
                }
            }
            return wholeBody;
        }

        private string GetCachedBiome(Vessel vessel)
        {
            float now = Time.time;
            if (_biomeCacheTime < 0f || (now - _biomeCacheTime) >= BiomeRefreshInterval)
            {
                _cachedBiome = ResolveBiome(vessel);
                _biomeCacheTime = now;
            }
            return _cachedBiome;
        }

        private static string ResolveBiome(Vessel vessel)
        {
            CelestialBody body = vessel.mainBody;
            if (body == null || body.BiomeMap == null) return string.Empty;
            string biome = ScienceUtil.GetExperimentBiome(body, vessel.latitude, vessel.longitude);
            return biome ?? string.Empty;
        }

        private void SetActiveConfig(PrecipitationConfig cfg)
        {
            if (_active == cfg) return;
            _active = cfg;
            _emitCarry = 0f;
            if (_ps != null) _ps.Clear();
            if (cfg == null) return;
            _needsPrewarm = true;

            ParticleSystem.MainModule main = _ps.main;
            main.maxParticles = cfg.MaxParticles;

            Texture tex = null;
            if (!string.IsNullOrEmpty(cfg.texture))
            {
                tex = GameDatabase.Instance.GetTexture(cfg.texture, false);
                if (tex == null)
                {
                    Debug.LogWarning(LogTag + " Texture '" + cfg.texture + "' not found in GameDatabase; using procedural dot.");
                }
            }
            _material.mainTexture = tex != null ? tex : GetProceduralDot();

            if (cfg.type == PrecipType.Rain && cfg.streakScale > 0f)
            {
                _renderer.renderMode = ParticleSystemRenderMode.Stretch;
                _renderer.velocityScale = cfg.streakScale;
                _renderer.lengthScale = 0f;
            }
            else
            {
                _renderer.renderMode = ParticleSystemRenderMode.Billboard;
            }

            ParticleSystem.NoiseModule noise = _ps.noise;
            noise.enabled = cfg.flutter > 0f;
            if (noise.enabled)
            {
                noise.strength = cfg.flutter;
                noise.frequency = 0.5f;
                noise.scrollSpeed = 0.35f;
                noise.quality = ParticleSystemNoiseQuality.Medium;
            }

            _windAzimuthSeed = Random.onUnitSphere;
            Debug.Log(LogTag + " Activated " + cfg.type + " on " + cfg.body + ".");
        }


        private void LateUpdate()
        {
            if (_ps == null) return;

            Vessel vessel = FlightGlobals.ActiveVessel;
            if (vessel == null || !FlightGlobals.ready)
            {
                SetActiveConfig(null);
                return;
            }

            PrecipitationConfig cfg = SelectConfig(vessel);
            if (cfg == null
                || vessel.altitude > cfg.maxAltitude
                || vessel.srfSpeed > cfg.maxSurfaceSpeed)
            {
                SetActiveConfig(null);
                return;
            }
            SetActiveConfig(cfg);

            FlightCamera flightCam = FlightCamera.fetch;
            if (flightCam == null || flightCam.mainCamera == null) return;
            Transform cam = flightCam.mainCamera.transform;

            Vector3d bodyPos = vessel.mainBody.position;
            Vector3 up = (Vector3)((Vector3d)cam.position - bodyPos).normalized;

            Vector3 right = Vector3.Cross(up, Vector3.forward);
            if (right.sqrMagnitude < 1e-4f) right = Vector3.Cross(up, Vector3.right);
            right.Normalize();
            Vector3 forward = Vector3.Cross(up, right);

            Vector3 windDir = Vector3.ProjectOnPlane(_windAzimuthSeed, up).normalized;
            float gust = 0.65f + 0.35f * Mathf.PerlinNoise(Time.time * 0.13f, 0.5f);
            Vector3 wind = windDir * (cfg.windSpeed * gust);

            float fadeStart = cfg.maxAltitude * (1f - cfg.fadeFraction);
            float intensity = 1f;
            if (vessel.altitude > fadeStart)
            {
                intensity = 1f - Mathf.Clamp01(((float)vessel.altitude - fadeStart) / (cfg.maxAltitude * cfg.fadeFraction));
            }

            if (_needsPrewarm)
            {
                PrewarmColumn(cfg, cam.position, up, right, forward, wind);
                _needsPrewarm = false;
            }

            EmitParticles(cfg, cam.position, up, right, forward, wind, intensity);
        }

        private void PrewarmColumn(PrecipitationConfig cfg, Vector3 camPos, Vector3 up,
                                   Vector3 right, Vector3 forward, Vector3 wind)
        {
            int target = Mathf.Min((int)(cfg.emissionRate * cfg.Lifetime), cfg.MaxParticles - 64);
            for (int i = 0; i < target; i++)
            {
                Vector2 disc = Random.insideUnitCircle * cfg.areaRadius;
                float t = Random.value;
                float h = Mathf.Lerp(cfg.spawnHeight, -cfg.killDepth, t);

                _emit.position = camPos + up * h + right * disc.x + forward * disc.y;
                _emit.velocity = (-up * cfg.fallSpeed) + wind
                                 + Random.insideUnitSphere * cfg.velocityJitter;
                _emit.startSize = Random.Range(cfg.sizeMin, cfg.sizeMax);
                _emit.startLifetime = cfg.Lifetime * (1f - t);

                Color c = cfg.color;
                c.a *= Random.Range(0.75f, 1f);
                _emit.startColor = c;
                _ps.Emit(_emit, 1);
            }
        }

        private void EmitParticles(PrecipitationConfig cfg, Vector3 camPos, Vector3 up,
                                   Vector3 right, Vector3 forward, Vector3 wind, float intensity)
        {
            _emitCarry += cfg.emissionRate * intensity * Time.deltaTime;
            int count = (int)_emitCarry;
            if (count <= 0) return;
            if (count > MaxEmitPerFrame) count = MaxEmitPerFrame;
            _emitCarry -= count;

            float lifetime = cfg.Lifetime;
            Vector3 spawnCenter = camPos + up * cfg.spawnHeight;

            for (int i = 0; i < count; i++)
            {
                Vector2 disc = Random.insideUnitCircle * cfg.areaRadius;
                _emit.position = spawnCenter + right * disc.x + forward * disc.y;
                _emit.velocity = (-up * cfg.fallSpeed) + wind
                                 + Random.insideUnitSphere * cfg.velocityJitter;
                _emit.startSize = Random.Range(cfg.sizeMin, cfg.sizeMax);
                _emit.startLifetime = lifetime;

                Color c = cfg.color;
                c.a *= Random.Range(0.75f, 1f);
                _emit.startColor = c;

                _ps.Emit(_emit, 1);
            }
        }

    }
}
